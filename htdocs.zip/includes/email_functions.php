<?php
/**
 * Email Functions for Zoho Mail
 */

// Email configuration for Zoho
define('EMAIL_HOST', 'smtp.zoho.com');
define('EMAIL_PORT', 587); // or 465 for SSL
define('EMAIL_USERNAME', 'account@dichvutot.site'); // Replace with your Zoho email
define('EMAIL_PASSWORD', '#4Vrorcl'); // Replace with your Zoho password or app password
define('EMAIL_FROM_NAME', 'Book Review Portal'); // Your website name
define('EMAIL_FROM_ADDRESS', 'account@dichvutot.site'); // Replace with your Zoho email

/**
 * Send an email using PHPMailer and Zoho Mail
 * 
 * @param string $to Recipient email address
 * @param string $subject Email subject
 * @param string $body Email body (HTML)
 * @param string $altBody Plain text version of the email
 * @return array Success status and message
 */
function sendEmail($to, $subject, $body, $altBody = '') {
    // Check if PHPMailer is installed
    if (!class_exists('PHPMailer\PHPMailer\PHPMailer')) {
        // Try to load from composer autoload
        $autoloadPaths = [
            __DIR__ . '/../vendor/autoload.php',
            __DIR__ . '/../../vendor/autoload.php',
        ];
        
        $loaded = false;
        foreach ($autoloadPaths as $path) {
            if (file_exists($path)) {
                require_once $path;
                $loaded = true;
                break;
            }
        }
        
        if (!$loaded) {
            error_log('PHPMailer not found. Please install it using Composer.');
            return [
                'success' => false,
                'message' => 'Email system not configured correctly'
            ];
        }
    }
    
    try {
        $mail = new PHPMailer\PHPMailer\PHPMailer(true);
        
        // Server settings
        $mail->isSMTP();
        $mail->Host = EMAIL_HOST;
        $mail->SMTPAuth = true;
        $mail->Username = EMAIL_USERNAME;
        $mail->Password = EMAIL_PASSWORD;
        $mail->SMTPSecure = 'tls'; // tls or ssl
        $mail->Port = EMAIL_PORT;
        $mail->CharSet = 'UTF-8';
        
        // Recipients
        $mail->setFrom(EMAIL_FROM_ADDRESS, EMAIL_FROM_NAME);
        $mail->addAddress($to);
        
        // Content
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body = $body;
        $mail->AltBody = $altBody ?: strip_tags($body);
        
        $mail->send();
        
        return [
            'success' => true,
            'message' => 'Email sent successfully'
        ];
    } catch (Exception $e) {
        error_log('Email sending failed: ' . $e->getMessage());
        return [
            'success' => false,
            'message' => 'Không thể gửi email: ' . $e->getMessage()
        ];
    }
}

/**
 * Send verification email to the user
 * 
 * @param string $email User's email address
 * @param string $username User's username
 * @param string $token Verification token
 * @param string $fullName User's full name
 * @return array Success status and message
 */
function sendVerificationEmail($email, $username, $token, $fullName = '') {
    $subject = 'Xác minh tài khoản của bạn';
    
    // Create verification link
    $verificationLink = 'http://' . $_SERVER['HTTP_HOST'] . '/verify-email.php?token=' . $token . '&email=' . urlencode($email);
    
    // Display name - use full name if available, otherwise username
    $displayName = !empty($fullName) ? $fullName : $username;
    
    // Create email body
    $body = '
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #eee; border-radius: 5px;">
        <div style="text-align: center; margin-bottom: 20px;">
            <h2 style="color: #4a6fdc;">Xác minh tài khoản</h2>
        </div>
        
        <p>Xin chào <strong>' . htmlspecialchars($displayName) . '</strong>,</p>
        
        <p>Cảm ơn bạn đã đăng ký tài khoản tại Book Review Portal. Để hoàn tất quá trình đăng ký, vui lòng xác minh email của bạn bằng cách nhấp vào nút bên dưới:</p>
        
        <div style="text-align: center; margin: 30px 0;">
            <a href="' . $verificationLink . '" style="background-color: #4a6fdc; color: white; padding: 12px 30px; text-decoration: none; border-radius: 4px; font-weight: bold;">
                Xác minh email
            </a>
        </div>
        
        <p>Hoặc bạn có thể sao chép và dán liên kết sau vào trình duyệt:</p>
        <p style="word-break: break-all;">' . $verificationLink . '</p>
        
        <p>Nếu bạn không đăng ký tài khoản này, vui lòng bỏ qua email này.</p>
        
        <div style="margin-top: 40px; padding-top: 20px; border-top: 1px solid #eee; font-size: 12px; color: #666;">
            <p>Email này được gửi tự động, vui lòng không trả lời.</p>
        </div>
    </div>
    ';
    
    return sendEmail($email, $subject, $body);
}

/**
 * Send welcome email to the user after verification
 * 
 * @param string $email User's email address
 * @param string $username User's username
 * @param string $fullName User's full name
 * @return array Success status and message
 */
function sendWelcomeEmail($email, $username, $fullName = '') {
    $subject = 'Chào mừng bạn đến với Book Review Portal!';
    
    // Display name - use full name if available, otherwise username
    $displayName = !empty($fullName) ? $fullName : $username;
    
    // Website URL
    $websiteUrl = 'http://' . $_SERVER['HTTP_HOST'];
    
    // Create email body
    $body = '
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #eee; border-radius: 5px;">
        <div style="text-align: center; margin-bottom: 20px;">
            <h2 style="color: #4a6fdc;">Chào mừng đến với Book Review Portal!</h2>
        </div>
        
        <p>Xin chào <strong>' . htmlspecialchars($displayName) . '</strong>,</p>
        
        <p>Cảm ơn bạn đã xác minh email và hoàn tất đăng ký tài khoản. Chúng tôi rất vui mừng chào đón bạn tham gia vào cộng đồng của chúng tôi!</p>
        
        <p>Với tài khoản của bạn, bạn có thể:</p>
        <ul style="padding-left: 20px; line-height: 1.5;">
            <li>Đọc và viết đánh giá sách</li>
            <li>Lưu sách yêu thích vào danh sách cá nhân</li>
            <li>Tương tác với các thành viên khác</li>
            <li>Nhận thông báo về sách mới và các chủ đề bạn quan tâm</li>
        </ul>
        
        <div style="text-align: center; margin: 30px 0;">
            <a href="' . $websiteUrl . '" style="background-color: #4a6fdc; color: white; padding: 12px 30px; text-decoration: none; border-radius: 4px; font-weight: bold;">
                Khám phá ngay
            </a>
        </div>
        
        <p>Nếu bạn có bất kỳ câu hỏi hoặc góp ý nào, đừng ngần ngại liên hệ với chúng tôi.</p>
        
        <p>Chúc bạn có những trải nghiệm tuyệt vời!</p>
        
        <div style="margin-top: 40px; padding-top: 20px; border-top: 1px solid #eee; font-size: 12px; color: #666;">
            <p>Email này được gửi tự động từ Book Review Portal.</p>
        </div>
    </div>
    ';
    
    return sendEmail($email, $subject, $body);
}
