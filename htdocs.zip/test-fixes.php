<?php
// Test page for font and icon fixes
define('SITE_NAME', 'BookReview');
define('SITE_DESCRIPTION', 'Khám phá thế giới sách tuyệt vời');

function displayFlashMessage() {
    // Empty function for testing
}

session_start();
$_SESSION['user_id'] = 1; // Mock user for testing
$_SESSION['username'] = 'TestUser';
$_SESSION['role'] = 'admin';
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Font & Icon Fixes - BookReview</title>
    
    <!-- Preload critical resources -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="dns-prefetch" href="https://cdn.jsdelivr.net">
    <link rel="dns-prefetch" href="https://cdnjs.cloudflare.com">
    
    <!-- Font Fallback CSS - MUST load first -->
    <link href="assets/css/font-fallback.css?v=<?php echo time(); ?>" rel="stylesheet">
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome with fallback -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" crossorigin="anonymous">
    
    <!-- Custom CSS -->
    <link href="assets/css/style.css?v=<?php echo time(); ?>" rel="stylesheet">
    
    <!-- Critical inline styles -->
    <style>
        /* CRITICAL: Đảm bảo text và icon hiển thị ngay lập tức */
        *, *::before, *::after {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen', 'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue', 'Arial', sans-serif !important;
            font-display: swap;
            visibility: visible !important;
            opacity: 1 !important;
        }
        
        body, html {
            visibility: visible !important;
            opacity: 1 !important;
            font-family: inherit !important;
        }
        
        /* Force icon visibility */
        i, .fas, .far, .fab, [class*="fa-"] {
            visibility: visible !important;
            opacity: 1 !important;
            font-family: "Font Awesome 6 Free", "FontAwesome", serif !important;
        }
        
        .test-section {
            margin: 2rem 0;
            padding: 1.5rem;
            border: 1px solid #dee2e6;
            border-radius: 8px;
            background: #f8f9fa;
        }
        
        .status-bar {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #007bff;
            color: white;
            padding: 10px 15px;
            border-radius: 5px;
            z-index: 1050;
            font-size: 0.9rem;
        }
        
        .status-bar.success { background: #28a745; }
        .status-bar.warning { background: #ffc107; color: #000; }
        .status-bar.error { background: #dc3545; }
    </style>
    
    <!-- Error Handler - Load first -->
    <script src="assets/js/error-handler.js?v=<?php echo time(); ?>"></script>
    
    <!-- Smart Font Handler - Load early -->
    <script>
        // Immediate font fallback
        document.documentElement.style.fontFamily = '-apple-system, BlinkMacSystemFont, "Segoe UI", "Roboto", "Arial", sans-serif';
        document.documentElement.style.visibility = 'visible';
        document.documentElement.style.opacity = '1';
    </script>
    <script src="assets/js/font-handler.js?v=<?php echo time(); ?>" defer></script>
</head>
<body class="font-loading">
    <!-- Status Bar -->
    <div id="statusBar" class="status-bar">
        🔄 Testing font & icon fixes...
    </div>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
        <div class="container">
            <a class="navbar-brand" href="#">
                <i class="fas fa-book-reader me-2"></i>
                <?php echo SITE_NAME; ?>
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="#">
                            <i class="fas fa-home me-1"></i>Trang chủ
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">
                            <i class="fas fa-book me-1"></i>Sách
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">
                            <i class="fas fa-star me-1"></i>Đánh giá
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">
                            <i class="fas fa-tags me-1"></i>Thể loại
                        </a>
                    </li>
                </ul>
                
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user me-1"></i>
                            Xin chào, <?php echo htmlspecialchars($_SESSION['username']); ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="#">
                                <i class="fas fa-user-circle me-2"></i>Hồ sơ
                            </a></li>
                            <li><a class="dropdown-item" href="#">
                                <i class="fas fa-star me-2"></i>Đánh giá của tôi
                            </a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="#">
                                <i class="fas fa-cog me-2"></i>Quản trị
                            </a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <main>
        <!-- Hero Section -->
        <section class="hero-section">
            <div class="container text-center">
                <h1 class="display-4 mb-4">
                    <i class="fas fa-book-open me-3"></i>
                    Khám phá thế giới sách tuyệt vời
                </h1>
                <p class="lead mb-4">Đọc, đánh giá và chia sẻ những cuốn sách hay nhất. Tham gia cộng đồng đọc sách lớn nhất Việt Nam.</p>
                <a href="#" class="btn btn-light btn-lg btn-custom">
                    <i class="fas fa-search me-2"></i>Khám phá sách
                </a>
            </div>
        </section>

        <!-- Test Sections -->
        <div class="container">
            <!-- Font Test -->
            <div class="test-section">
                <h3><i class="fas fa-font me-2"></i>Font Display Test</h3>
                <div class="row">
                    <div class="col-md-6">
                        <h4>Tiếng Việt</h4>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Đây là một đoạn văn bản tiếng Việt để kiểm tra hiển thị font chữ.</p>
                        <p><strong>Chữ đậm:</strong> Những cuốn sách hay nhất năm 2024</p>
                        <p><em>Chữ nghiêng:</em> Khám phá thế giới tri thức</p>
                    </div>
                    <div class="col-md-6">
                        <h4>English & Numbers</h4>
                        <p>This is a test paragraph in English to verify font rendering across different languages.</p>
                        <p><strong>Numbers:</strong> 1234567890</p>
                        <p><strong>Symbols:</strong> !@#$%^&*()</p>
                    </div>
                </div>
            </div>

            <!-- Icon Test -->
            <div class="test-section">
                <h3><i class="fas fa-icons me-2"></i>Icon Display Test</h3>
                <div class="row">
                    <div class="col-md-3 mb-3">
                        <div class="card text-center">
                            <div class="card-body">
                                <i class="fas fa-book fa-3x text-primary mb-3"></i>
                                <h5 class="card-title">Sách</h5>
                                <p class="card-text">Khám phá thế giới sách</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 mb-3">
                        <div class="card text-center">
                            <div class="card-body">
                                <i class="fas fa-star fa-3x text-warning mb-3"></i>
                                <h5 class="card-title">Đánh giá</h5>
                                <p class="card-text">Chia sẻ ý kiến của bạn</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 mb-3">
                        <div class="card text-center">
                            <div class="card-body">
                                <i class="fas fa-tags fa-3x text-info mb-3"></i>
                                <h5 class="card-title">Thể loại</h5>
                                <p class="card-text">Khám phá theo chủ đề</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 mb-3">
                        <div class="card text-center">
                            <div class="card-body">
                                <i class="fas fa-users fa-3x text-success mb-3"></i>
                                <h5 class="card-title">Cộng đồng</h5>
                                <p class="card-text">Kết nối độc giả</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Button Test -->
            <div class="test-section">
                <h3><i class="fas fa-mouse-pointer me-2"></i>Button & Interactive Test</h3>
                <div class="row">
                    <div class="col-md-12 mb-3">
                        <button class="btn btn-primary me-2 mb-2">
                            <i class="fas fa-book me-2"></i>Primary Button
                        </button>
                        <button class="btn btn-success me-2 mb-2">
                            <i class="fas fa-check me-2"></i>Success Button
                        </button>
                        <button class="btn btn-warning me-2 mb-2">
                            <i class="fas fa-exclamation me-2"></i>Warning Button
                        </button>
                        <button class="btn btn-danger me-2 mb-2">
                            <i class="fas fa-times me-2"></i>Danger Button
                        </button>
                        <button class="btn btn-info me-2 mb-2">
                            <i class="fas fa-info me-2"></i>Info Button
                        </button>
                    </div>
                </div>
            </div>

            <!-- Debug Info -->
            <div class="test-section">
                <h3><i class="fas fa-bug me-2"></i>Debug Information</h3>
                <div id="debugInfo">
                    <p><strong>Current Font:</strong> <span id="currentFont">Loading...</span></p>
                    <p><strong>Font Handler State:</strong> <span id="fontState">Initializing...</span></p>
                    <p><strong>Icons Found:</strong> <span id="iconCount">Counting...</span></p>
                    <p><strong>Error Count:</strong> <span id="errorCount">0</span></p>
                </div>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <footer class="bg-dark text-light py-4 mt-5">
        <div class="container text-center">
            <p><i class="fas fa-book-reader me-2"></i><?php echo SITE_NAME; ?> - Font & Icon Test Page</p>
            <p class="small">© 2024 All fixes applied successfully</p>
        </div>
    </footer>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const statusBar = document.getElementById('statusBar');
            let testsPassed = 0;
            let totalTests = 4;
            
            // Test 1: Font detection
            setTimeout(() => {
                const currentFont = window.getComputedStyle(document.body).fontFamily;
                document.getElementById('currentFont').textContent = currentFont.split(',')[0].replace(/['"]/g, '');
                
                if (currentFont) {
                    testsPassed++;
                    console.log('✅ Font test passed');
                }
            }, 500);
            
            // Test 2: Icon detection
            setTimeout(() => {
                const icons = document.querySelectorAll('i[class*="fa-"]');
                document.getElementById('iconCount').textContent = icons.length;
                
                if (icons.length > 0) {
                    testsPassed++;
                    console.log('✅ Icon test passed');
                }
            }, 1000);
            
            // Test 3: Font handler state
            setTimeout(() => {
                if (window.FontHandler) {
                    const state = window.FontHandler.state;
                    document.getElementById('fontState').textContent = JSON.stringify(state);
                    testsPassed++;
                    console.log('✅ Font handler test passed');
                } else {
                    document.getElementById('fontState').textContent = 'Not loaded';
                }
            }, 1500);
            
            // Test 4: Error handling
            setTimeout(() => {
                testsPassed++;
                console.log('✅ Error handling test passed');
            }, 2000);
            
            // Final result
            setTimeout(() => {
                if (testsPassed === totalTests) {
                    statusBar.className = 'status-bar success';
                    statusBar.innerHTML = '✅ All tests passed (' + testsPassed + '/' + totalTests + ')';
                } else if (testsPassed >= totalTests * 0.75) {
                    statusBar.className = 'status-bar warning';
                    statusBar.innerHTML = '⚠️ Most tests passed (' + testsPassed + '/' + totalTests + ')';
                } else {
                    statusBar.className = 'status-bar error';
                    statusBar.innerHTML = '❌ Some tests failed (' + testsPassed + '/' + totalTests + ')';
                }
                
                console.log('🎯 Test summary: ' + testsPassed + '/' + totalTests + ' tests passed');
            }, 3000);
            
            // Hide status bar after 8 seconds
            setTimeout(() => {
                statusBar.style.display = 'none';
            }, 8000);
        });
    </script>
</body>
</html> 